/* Experimental I/O-only half-cycle adapter over the generated C core.
 * One rising call per T-state; every rising call must have a falling call.
 * Supply live bus data before the falling call. Reset cancels pending work.
 * Non-I/O behavior retains the original whole-cycle model. */
/* Core already included through the shadow CPU header. */
typedef struct { z80_t cpu; uint64_t pins; int pending; } c_read_half;
static int c_read_consuming(unsigned step) {
 switch(step){case 974:case 1188:case 1222:case 1256:case 1285:case 1314:case 1352:case 1390:case 1418:case 1463:case 1495:case 1537:case 1589:return 1;default:return 0;}
}
static int c_read_waiting(unsigned step) {
 switch(step){case 973:case 1187:case 1221:case 1255:case 1284:case 1313:case 1351:case 1389:case 1417:case 1462:case 1494:case 1536:case 1588:return 1;default:return 0;}
}
static int c_write_waiting(unsigned step) {switch(step){case 923:case 1191:case 1225:case 1259:case 1288:case 1317:case 1355:case 1393:case 1421:case 1473:case 1505:case 1552:case 1604:return 1;default:return 0;}}
static void c_read_reset(c_read_half *c) {
 c->pins=z80_init(&c->cpu);c->pending=0;
}
static uint64_t c_read_rise(c_read_half *c,uint64_t pins) {
 c->pending=c_write_waiting(c->cpu.step)?3:(((pins&(Z80_IORQ|Z80_WR))==(Z80_IORQ|Z80_WR))?4:(c_read_consuming(c->cpu.step)?1:(c_read_waiting(c->cpu.step)?2:0)));
 c->pins=c->pending?pins:z80_tick(&c->cpu,pins);
 return c->pins;
}
static uint64_t c_read_fall(c_read_half *c,uint64_t pins) {
 if(c->pending){
  uint64_t selected=pins&(UINT64_C(0xffffff)|Z80_IORQ|Z80_WR);
  c->pins=z80_tick(&c->cpu,pins);
  if(c->pending==3)c->pins=(c->pins&~(UINT64_C(0xffffff)|Z80_IORQ|Z80_WR))|selected;
  if(c->pending==4){c->pins&=~(Z80_IORQ|Z80_WR);}
  // Release after sampling at T3 falling; internal register changes precede
  // the next rising-edge machine cycle. No instruction T-state is added.
  if(c->pending==1)c->pins&=~(Z80_IORQ|Z80_RD);
  c->pending=0;
 }else c->pins=pins;
 return c->pins;
}
