`timescale 1ns/1ps
module firmware_tb #(
 parameter ROM_READ_ENVELOPE=0,
 parameter CLOCK_HALF_NS=5,
 parameter FLOATING_IO_OVERRIDE=0,
 parameter FLOATING_IO_SEQUENCE=0,
 parameter [7:0] FLOATING_IO_VALUE=8'hff
);
 reg clk=0,reset_n=0;always #(CLOCK_HALF_NS) clk=~clk;
 wire cpu_clk,cpu_reset_n;
 // Reproducible bench stimulus enters the CPU sides of open BR1/BR2.
 controller_service service_boundary(.oscillator(1'b0),.reset_source_n(1'b1),
  .br1_closed(1'b0),.br2_closed(1'b0),.external_clk(clk),
  .external_reset_n(reset_n),.cpu_clk(cpu_clk),.cpu_reset_n(cpu_reset_n));
 wire [15:0] address;wire [7:0] dout,di,read_data;wire m1_n,mreq_n,iorq_n,rd_n,wr_n,rfsh_n,halt_n,busak_n;
 reg [103:0] contacts=0;wire [1:0] leds;wire ta_daten,ta_takt;
 reg [7:0] rom[0:2047];reg [1023:0] file,wave;integer cycle=-16,wave_start=0,wave_end=1900000;reg wave_enabled=0;
 tv80_io_candidate cpu(.reset_n(cpu_reset_n),.clk(cpu_clk),.wait_n(1'b1),.int_n(1'b1),.nmi_n(1'b1),.busrq_n(1'b1),.di(di),.A(address),.dout(dout),.m1_n(m1_n),.mreq_n(mreq_n),.iorq_n(iorq_n),.rd_n(rd_n),.wr_n(wr_n),.rfsh_n(rfsh_n),.halt_n(halt_n),.busak_n(busak_n));
 controller board(address,dout,iorq_n,wr_n,contacts,read_data,leds,ta_daten,ta_takt);
 // A15 low disables the 8282 outputs. The standard digital board's pullups
 // are a boundary convention, not evidence that the physical bus reads FF.
 // This fixture override explores firmware dependence on released I/O reads.
 wire [7:0] rom_read;
 generate if(ROM_READ_ENVELOPE) begin: timed_rom
  eprom2716_read_envelope access(.address(address[10:0]),.data(rom[address[10:0]]),
   .ce_n(1'b0),.oe_n(mreq_n),.q(rom_read));
 end else begin: immediate_rom
  assign rom_read=rom[address[10:0]];
 end endgenerate
 // Direct CPU input remains a digital fixture; this does not resolve bus
 // contention or output release in SPICE. Clock units must match the ns model.
 // Advance only after a released read ends, keeping its input byte stable.
 // The odd multiplier permutes all 256 byte values before repeating.
 wire released_io_read=mreq_n && !iorq_n && !rd_n && !address[15];
 reg [7:0] floating_index=0;
 wire [7:0] floating_sequence_byte=8'd73*floating_index+8'h37;
 reg floating_active=0;
 always @(released_io_read or cpu_reset_n) begin
  if(cpu_reset_n!==1'b1)begin floating_index<=0;floating_active<=0;end
  else if(FLOATING_IO_OVERRIDE && FLOATING_IO_SEQUENCE) begin
   if(released_io_read===1'b1)floating_active<=1;
   else if(released_io_read===1'b0 && floating_active)begin
    $display("FLOATING_IO %0t %02x",$time,floating_sequence_byte);
    floating_index<=floating_index+1'b1;floating_active<=0;
   end
  end
 end
 assign di=!mreq_n?rom_read:
           FLOATING_IO_OVERRIDE && !iorq_n && !rd_n && !address[15] ?
           (FLOATING_IO_SEQUENCE?floating_sequence_byte:FLOATING_IO_VALUE):read_data;
 initial begin
  if(!$value$plusargs("rom=%s",file))$fatal(1,"rom missing");$readmemh(file,rom);
  if($value$plusargs("wave=%s",wave))begin
   wave_enabled=1;
   if($value$plusargs("wave_start=%d",wave_start))begin end
   if($value$plusargs("wave_end=%d",wave_end))begin end
   $dumpfile(wave);$dumpvars(0,firmware_tb);
   if(wave_start>0)$dumpoff;
  end
 end
 always @(negedge clk)begin
  cycle=cycle+1;
  if(cycle==0)reset_n=1;
  case(cycle)
200000:contacts[16]=1;
300000:contacts=0;
400000:contacts[17]=1;
500000:contacts=0;
600000:contacts[18]=1;
700000:contacts=0;
800000:contacts[19]=1;
900000:contacts=0;
1000000:contacts[20]=1;
1100000:contacts=0;
1200000:contacts[21]=1;
1300000:contacts=0;
1400000:contacts[22]=1;
1500000:contacts=0;
1600000:contacts[23]=1;
1700000:contacts=0;
  endcase

  if(wave_enabled && cycle==wave_start)$dumpon;
  if(wave_enabled && cycle>=wave_end)begin $dumpflush;$finish;end
  if(cycle==1900000)begin $display("DONE %0d",cycle);$finish;end
 end
 reg [2:0] previous_bus=0;
 wire [2:0] observed_bus={!rd_n,!wr_n,!iorq_n};
 always @(negedge clk) begin
  #1;
  if(reset_n && cycle>=0 && observed_bus[1:0]!=0 && observed_bus!==previous_bus)
   $display("BUS %0d %0d %0d %0d",cycle,observed_bus,address,wr_n?di:dout);
  previous_bus=observed_bus;
 end
 always @(posedge clk)begin #1;if(cycle>=0&&cycle%200000==199999)$display("LED %0d %0d",cycle,leds);end
 always @(leds) if(reset_n && cycle>=0)$display("EDGE %0d %0d",cycle,leds);
 always @(posedge ta_takt) if(reset_n)begin #1;$display("BIT %0d %0d",cycle,~ta_daten);end
endmodule
