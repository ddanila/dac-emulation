#include "/Users/ddanila/fun/dac-emulation/build/keyboard-controller-io-boundary-firmware/shadow/machines/robotron1715m/keyboard.h"
#include <stdio.h>
#include <stdlib.h>
static unsigned cycle;
static unsigned previous_bus;
static void bit(void *u,unsigned value){(void)u;printf("BIT %u %u\n",cycle,value);}
int main(int argc,char **argv){
 if(argc!=2)return 2;
 unsigned char rom[2048];FILE *f=fopen(argv[1],"rb");if(!f)return 2;
 if(fread(rom,1,sizeof rom,f)!=sizeof rom||fgetc(f)!=EOF)return 2;
 fclose(f);
 robotron_keyboard k;robotron_keyboard_init(&k,rom,NULL,bit);
 printf("EDGE 0 %u\n",k.leds);
 for(cycle=0;cycle<1900000;cycle++){
  unsigned old_leds=k.leds;
if(cycle==200000)robotron_keyboard_key(&k,0,0,1);
if(cycle==300000)robotron_keyboard_release(&k);
if(cycle==400000)robotron_keyboard_key(&k,0,1,1);
if(cycle==500000)robotron_keyboard_release(&k);
if(cycle==600000)robotron_keyboard_key(&k,0,2,1);
if(cycle==700000)robotron_keyboard_release(&k);
if(cycle==800000)robotron_keyboard_key(&k,0,3,1);
if(cycle==900000)robotron_keyboard_release(&k);
if(cycle==1000000)robotron_keyboard_key(&k,0,4,1);
if(cycle==1100000)robotron_keyboard_release(&k);
if(cycle==1200000)robotron_keyboard_key(&k,0,5,1);
if(cycle==1300000)robotron_keyboard_release(&k);
if(cycle==1400000)robotron_keyboard_key(&k,0,6,1);
if(cycle==1500000)robotron_keyboard_release(&k);
if(cycle==1600000)robotron_keyboard_key(&k,0,7,1);
if(cycle==1700000)robotron_keyboard_release(&k);
  if(1)dac_z80_tick(&k.cpu,0,0);
  unsigned bus=(!!(k.cpu.pins & Z80_IORQ)) | ((!!(k.cpu.pins & Z80_WR))<<1) | ((!!(k.cpu.pins & Z80_RD))<<2);
  if((bus&3) && bus!=previous_bus)printf("BUS %u %u %u %u\n",cycle,bus,Z80_GET_ADDR(k.cpu.pins),Z80_GET_DATA(k.cpu.pins));
  previous_bus=bus;
  if(k.leds!=old_leds)printf("EDGE %u %u\n",cycle,k.leds);
  if(cycle%200000==199999)printf("LED %u %u\n",cycle,k.leds);
 }
 printf("DONE %u\n",cycle);
 return 0;
}
